# vigenere cipher 

# encryption

# align the key with the plaintext

# shift each letter

# decryption

# shift each letter

# align the key with the plaintext 